FT.manifest({
  "filename": "index.html",
  "width": 300,
  "height": 250,
  "clickTagCount": 1,
  "hideBrowsers": ["ie8"],
  "richloads": [
   {"name":"main_rl", "src":"JetBlue_Card_Plus_FCB_Lifestyle_300x250_RL"}
 ],
  "instantAds": [
      {"name":"main_rl",          "type":"richload"}, 
      {"name":"clickTag1_url",    "type":"text", "default":"https://www.jetblue.com/trueblue/credit-cards/jetblue-card-comparison"}
  ]
});